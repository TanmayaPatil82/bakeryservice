package com.deloitte.Bakery.service;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deloitte.Bakery.entity.Bakery;
import com.deloitte.Bakery.repo.BakeryRepository;

@Service
public class BakeryServiceImpl  implements BakeryService{

	@Autowired
	BakeryRepository bakeryRepository;
	@Override
	public List<Bakery> getBakery() {
		// TODO Auto-generated method stub
		return bakeryRepository.findAll();
	}
	

	@Override
	public List<Bakery> getBake(Integer id) {
		// TODO Auto-generated method stub
		return bakeryRepository.findByCid(id);
	}

}

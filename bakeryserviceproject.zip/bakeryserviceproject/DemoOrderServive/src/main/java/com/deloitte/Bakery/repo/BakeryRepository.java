package com.deloitte.Bakery.repo;

import org.springframework.stereotype.Repository;


import com.deloitte.Bakery.entity.Bakery;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface BakeryRepository extends  JpaRepository<Bakery, Integer> {

	public List<Bakery> findByCid(Integer id);
	
	
	
}

package com.deloitte.Bakery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoBakeryServiveApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoBakeryServiveApplication.class, args);
	}

}

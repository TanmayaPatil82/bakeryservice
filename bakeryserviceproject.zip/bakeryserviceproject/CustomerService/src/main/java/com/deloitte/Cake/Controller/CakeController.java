package com.deloitte.Cake.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.deloitte.Cake.Entity.Cake;
import com.deloitte.Cake.Model.User;
import com.deloitte.Cake.Model.Response;
import com.deloitte.Cake.Service.CakeService;
import com.deloitte.Cake.Service.CakeServiceImpl;


@RestController
@RequestMapping("/Cake")
public class CakeController {

	
	@Autowired
	CakeService cakeService;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@GetMapping("/getCake")
	public ResponseEntity<List<Cake>> getAllCustomers(){
		
    List<Cake> Cakes=CakeService.getCakes();
		return new ResponseEntity<List<Cake>>(Cakes,HttpStatus.OK);
	}
	
	@GetMapping("/getCake/{Id}")
	public ResponseEntity<?> getCustomerByBnakId(@PathVariable("Id") Integer bankId) {
		
			Cake= CakeService.getCustomer(Id);
		List<User> CakeList=restTemplate.getForObject(""+Id,List.class);
		Response response=new Response(Cake,CakeList);
	
			return new ResponseEntity<Response>(response,HttpStatus.OK);
		}
}

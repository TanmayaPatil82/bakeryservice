package com.deloitte.Cake.Repository;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.deloitte.Cake.Entity.Cake;



@Repository
public interface CakeRepository extends  JpaRepository<Cake, Integer> {

	public List<Cake> findByBankId(Integer bankId);
}

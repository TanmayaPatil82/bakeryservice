package com.deloitte.Cake.Service;

import java.util.List;

import com.deloitte.Cake.Entity.Cake;



public interface CakeService {

	public List<Cake> getCakes();
	public List<Cake> getCake(Integer id);
}

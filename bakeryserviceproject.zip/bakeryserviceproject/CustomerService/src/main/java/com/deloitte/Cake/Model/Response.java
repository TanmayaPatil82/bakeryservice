package com.deloitte.Cake.Model;

import java.util.List;

import com.deloitte.Cake.Entity.Cake;

public class Response {

	private Cake customer;
	private List<User> bank;
	public Cake getCustomer() {
		return customer;
	}
	public void setCustomer(Cake customer) {
		this.customer = customer;
	}
	public List<User> getBank() {
		return bank;
	}
	public void setBank(List<User> bank) {
		this.bank = bank;
	}
	public Response(Cake customer, List<User> bank) {
		super();
		this.customer = customer;
		this.bank = bank;
	}
	public Response() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}

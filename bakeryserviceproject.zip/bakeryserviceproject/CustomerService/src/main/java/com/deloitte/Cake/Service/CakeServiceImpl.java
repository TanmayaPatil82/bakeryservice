package com.deloitte.Cake.Service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deloitte.Cake.Entity.Cake;
import com.deloitte.Cake.Repository.CakeRepository;


@Service
public class CakeServiceImpl implements CakeService {


	

	
	@Autowired
    CakeRepository cakeRepository;
	@Override
	public List<Cake> getCakes() {
		// TODO Auto-generated method stub
		return CakeRepository.findAll();
	}

	@Override
	public List<Cake> getCake(Integer id) {
		// TODO Auto-generated method stub
		return CakeRepository.findById(id);
	}

}

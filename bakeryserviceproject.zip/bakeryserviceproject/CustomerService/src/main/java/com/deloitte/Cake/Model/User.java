package com.deloitte.Cake.Model;

public class User {


	private int id;

	private String bankname;

	private String branch;
	
	
	
	public User() {
	
	}
	public User(int id, String bankname, String branch) {
		super();
		this.id = id;
		this.bankname = bankname;
		this.branch = branch;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBankname() {
		return bankname;
	}
	public void setBankname(String bankname) {
		this.bankname = bankname;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	
	
}

package com.deloitte.Cake.Entity;

import jakarta.persistence.Column;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Mycake")
public class Cake {
	
	@Id
	@GeneratedValue(strategy= GenerationType.AUTO)
	private  Integer orderId;
	private String Layers;
	private String Toppings;
	private String flavour;
	


	


	public Cake(Integer orderId, String layers, String toppings, String flavour) {
		super();
		this.orderId = orderId;
		Layers = layers;
		Toppings = toppings;
		this.flavour = flavour;
	}





	public Integer getOrderId() {
		return orderId;
	}





	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}





	public String getLayers() {
		return Layers;
	}





	public void setLayers(String layers) {
		Layers = layers;
	}





	public String getToppings() {
		return Toppings;
	}





	public void setToppings(String toppings) {
		Toppings = toppings;
	}





	public String getFlavour() {
		return flavour;
	}





	public void setFlavour(String flavour) {
		this.flavour = flavour;
	}


}